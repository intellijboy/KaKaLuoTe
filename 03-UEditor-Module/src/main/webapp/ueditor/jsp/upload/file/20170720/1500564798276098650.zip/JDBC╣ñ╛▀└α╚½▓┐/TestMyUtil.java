import com.jxufe.utils.JDBCUtil;
import org.junit.Test;

import java.sql.Connection;
import java.util.List;

/**
 * Created by liuburu on 2017/6/6.
 */
public class TestMyUtil {

    @Test
    public void testQuery() {
        String sql = "select stuId id,name,age,sex,motto from student";
        List<Student> students = JDBCUtil.queryList(Student.class, sql, null);
        for (Student student : students) {
            System.out.println(student);
        }
    }

    @Test
    public void testInsert() {
        String sql = "insert into student(name,age,sex,motto) values(?,?,?,?)";
        Connection connection = JDBCUtil.getConnection();
        int insertRow = JDBCUtil.update(connection, sql, "liuburu", 24, 1, "爱拼才会赢");
        System.out.println(insertRow > 0 ? "插入成功!" : "插入失败");
    }

    @Test
    public void testUpdate() {
        String sql = "update student set name = ? where stuId = ?";
        Connection connection = JDBCUtil.getConnection();
        int insertRow = JDBCUtil.update(connection, sql, "卡卡罗特444", 1008);
        System.out.println(insertRow > 0 ? "更新成功!" : "更新失败");
    }

    @Test
    public void testRemove() {
        String sql = "delete from student where stuId = ?";
        Connection connection = JDBCUtil.getConnection();
        int insertRow = JDBCUtil.update(connection, sql, 1008);
        System.out.println(insertRow > 0 ? "删除成功!" : "删除失败");
    }

    /**
     * 获取统计值或者字段值
     */
    @Test
    public void testGetValue() {
        String sql = "select count(1) from student where age > ?";
        //String sql ="select age from student where stuId = 1001";
        Object result = JDBCUtil.getValue(sql, 20);
        System.out.println("大于二十岁的人有?   " + result + "个");
       // System.out.println("ID为1001的年龄为？    " + result + "");
    }

    /**
     * 插入同时获取主键值
     */
    @Test
    public void testGetPrimaryKey(){
        String sql = "insert into student(name,age,sex,motto) values(?,?,?,?)";
        Connection connection = JDBCUtil.getConnection();
        Object keyValue = JDBCUtil.insert(connection, sql, "liuburu", 24, 1, "爱拼才会赢");
        System.out.println("返回主键值:"+keyValue);
    }


    @Test
    public void testTransaction(){
        String sql1 = "insert into student(name,age,sex,motto) values(?,?,?,?)";
        String sql2 = "insert into student(name,age,sex,motto) values(?,?,?,?)";
        Connection connection = JDBCUtil.getConnection();
        JDBCUtil.beginTransaction(connection);
        int resultRow1 = JDBCUtil.update(connection,sql1,"xiaoming", 24, 1, "爱拼才会赢");
        int resultRow2 = JDBCUtil.update(connection,sql2,"xiaohong", 20, 0, "七分靠打拼");
        System.out.println("insertRow1:"+resultRow1);
        System.out.println("insertRow2:"+resultRow2);
        JDBCUtil.rollback(connection);//回滚事务
       /// JDBCUtil.commit(connection);//提交事务
    }


}
